$(document).ready(function(){
	/*$('#footerCarousel').carousel({
	interval: 10000
	})
    
    $('#footerCarousel').on('slid.bs.carousel', function() {
    	//alert("slid");
	});
*/
	$('[data-toggle="popover"]').popover({ template : '<div class="popover" style="min-width: 480px;" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>' }); 
});